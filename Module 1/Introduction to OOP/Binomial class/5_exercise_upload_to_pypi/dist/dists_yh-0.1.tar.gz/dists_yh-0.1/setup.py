from setuptools import setup

setup(name='dists_yh',
      version='0.1',
      description='Gaussian and binomial distributions',
      packages=['dists_yh'],
      zip_safe=False)
